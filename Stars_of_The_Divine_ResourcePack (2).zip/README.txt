Stars of The Divine companion resource pack (Minecraft Java 26.2, pack format 88.0).
Normally delivered automatically by the server. Plain vanilla Nether Stars are not changed:
only Nether Stars carrying the mod's custom_model_data switch to the recoloured textures.
